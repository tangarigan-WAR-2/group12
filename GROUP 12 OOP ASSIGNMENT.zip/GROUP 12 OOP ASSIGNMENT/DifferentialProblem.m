classdef DifferentialProblem < NumericalProblem
    properties
        f       % function handle for dy/dt = f(t,y)
        y0      % initial value
        tspan   % time range [t0, tf]
    end

    methods
        function obj = DifferentialProblem(f, y0, tspan, name)
            obj.f = f;
            obj.y0 = y0;
            obj.tspan = tspan;
            obj.Name = name;
        end

        function result = solve(obj)
            % Simple Euler method
            t0 = obj.tspan(1);
            tf = obj.tspan(2);
            h = 0.1; % step size
            t = t0:h:tf;
            y = zeros(size(t));
            y(1) = obj.y0;

            for i = 1:length(t)-1
                y(i+1) = y(i) + h * obj.f(t(i), y(i));
            end

            result.t = t;
            result.y = y;
        end
    end
end  