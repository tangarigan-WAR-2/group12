clear; clc;

% Differential equation: dy/dt = -2y + sin(t), y(0) = 0
f = @(t,y) -2*y + sin(t);
diffProb = DifferentialProblem(f, 0, [0 5], 'ODE Example');
diffResult = diffProb.solve();

% Integral: ∫ sin(x) dx from 0 to pi
g = @(x) sin(x);
intProb = IntegralProblem(g, 0, pi, 100, 'Integral Example');
intResult = intProb.solve();

% Display results
fprintf('- %s - \n', diffProb.Name);
fprintf('y(5) ≈ %.4f\n', diffResult.y(end));

fprintf(' %s -\n', intProb.Name);
fprintf('Integral result ≈ %.4f\n', intResult);

% Optional: plot ODE result
figure;
plot(diffResult.t, diffResult.y, 'b-o');
xlabel('t'); ylabel('y');
title(diffProb.Name);