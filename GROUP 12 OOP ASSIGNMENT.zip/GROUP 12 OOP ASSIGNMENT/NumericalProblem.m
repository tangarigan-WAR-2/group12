classdef (Abstract) NumericalProblem
    % parent class
    properties
        Name
    end

    methods (Abstract)
        result = solve(obj); % Must be defined by child classes
    end
end