classdef IntegralProblem < NumericalProblem
    properties
        f   % function to integrate
        a   % lower limit
        b   % upper limit
        n   % number of subintervals
    end

    methods
        function obj = IntegralProblem(f, a, b, n, name)
            obj.f = f;
            obj.a = a;
            obj.b = b;
            obj.n = n;
            obj.Name = name;
        end

        function result = solve(obj)
            % Simple Trapezoidal rule
            h = (obj.b - obj.a) / obj.n;
            x = obj.a:h:obj.b;
            y = obj.f(x);
            result = h * (sum(y) - 0.5*(y(1) + y(end)));
        end
    end
end